/*
 * Copyright the original author or authors.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

package wallet.ui;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Toolbar;
import androidx.activity.EdgeToEdge;
import androidx.activity.SystemBarStyle;
import androidx.activity.result.ActivityResultLauncher;
import androidx.annotation.NonNull;
import androidx.core.graphics.Insets;
import androidx.core.view.MenuProvider;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.adapter.FragmentStateAdapter;
import androidx.viewpager2.widget.ViewPager2;
import org.bitcoinj.base.Address;
import org.bitcoinj.core.Transaction;
import org.bitcoinj.core.VerificationException;
import org.bitcoinj.wallet.Wallet;
import wallet.R;
import wallet.data.PaymentIntent;
import wallet.ui.scan.ScanActivity;
import wallet.util.ViewPagerTabs;
import wallet.util.ZoomOutPageTransformer;

public final class AddressBookActivity extends AbstractWalletActivity {
    public static void start(final Context context) {
        context.startActivity(new Intent(context, AddressBookActivity.class));
    }

    private AbstractWalletActivityViewModel walletActivityViewModel;
    private AddressBookViewModel viewModel;

    public static final int POSITION_WALLET_ADDRESSES = 0;
    public static final int POSITION_SENDING_ADDRESSES = 1;
    private static final int[] TAB_LABELS = { R.string.address_book_list_receiving_title,
            R.string.address_book_list_sending_title };

    private final ActivityResultLauncher<Void> scanLauncher =
            registerForActivityResult(new ScanActivity.Scan(), input -> {
                if (input == null) return;
                new InputParser.StringInputParser(input) {
                    @Override
                    protected void handlePaymentIntent(final PaymentIntent paymentIntent) {
                        if (paymentIntent.hasAddress()) {
                            final Wallet wallet = walletActivityViewModel.wallet.getValue();
                            final Address address = paymentIntent.getAddress();
                            if (!wallet.isAddressMine(address)) {
                                viewModel.showEditAddressBookEntryDialog.setValue(new Event<>(address));
                            } else {
                                viewModel.showScanOwnAddressDialog.setValue(Event.simple());
                            }
                        } else {
                            viewModel.showScanInvalidDialog.setValue(Event.simple());
                        }
                    }

                    @Override
                    protected void handleDirectTransaction(final Transaction transaction) throws VerificationException {
                        cannotClassify(input);
                    }

                    @Override
                    protected void error(final int messageResId, final Object... messageArgs) {
                        viewModel.showScanInvalidDialog.setValue(Event.simple());
                    }
                }.parse();
            });

    @Override
    protected void onCreate(final Bundle savedInstanceState) {
        EdgeToEdge.enable(this, SystemBarStyle.dark(getColor(R.color.bg_action_bar)),
                SystemBarStyle.light(Color.TRANSPARENT, Color.TRANSPARENT));
        super.onCreate(savedInstanceState);
        final FragmentManager fragmentManager = getSupportFragmentManager();

        setContentView(R.layout.address_book_content);
        final Toolbar appbar = findViewById(R.id.address_book_appbar);
        appbar.getNavigationIcon().setTint(getColor(R.color.fg_on_dark_bg_network_significant));
        setActionBar(appbar);
        getActionBar().setDisplayHomeAsUpEnabled(true);

        final ViewPager2 pager = findViewById(R.id.address_book_pager);
        final ViewPagerTabs pagerTabs = findViewById(R.id.address_book_pager_tabs);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.address_book_group), (v, windowInsets) -> {
            final Insets insets = windowInsets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(v.getPaddingLeft(), insets.top, v.getPaddingRight(), v.getPaddingBottom());
            return windowInsets;
        });

        pagerTabs.addTabLabels(TAB_LABELS);

        final boolean twoPanes = getResources().getBoolean(R.bool.address_book_two_panes);

        walletActivityViewModel = new ViewModelProvider(this).get(AbstractWalletActivityViewModel.class);
        walletActivityViewModel.wallet.observe(this, wallet -> invalidateOptionsMenu());
        viewModel = new ViewModelProvider(this).get(AddressBookViewModel.class);
        viewModel.pageTo.observe(this, new Event.Observer<Integer>() {
            @Override
            protected void onEvent(final Integer position) {
                if (!twoPanes)
                    pager.setCurrentItem(position, true);
            }
        });
        viewModel.showEditAddressBookEntryDialog.observe(this, new Event.Observer<Address>() {
            @Override
            protected void onEvent(final Address address) {
                EditAddressBookEntryFragment.edit(fragmentManager, address);
            }
        });
        viewModel.showScanOwnAddressDialog.observe(this, new Event.Observer<Void>() {
            @Override
            protected void onEvent(final Void v) {
                final DialogBuilder dialog = DialogBuilder.dialog(AddressBookActivity.this,
                        R.string.address_book_options_scan_title, R.string.address_book_options_scan_own_address);
                dialog.singleDismissButton(null);
                dialog.show();
            }
        });
        viewModel.showScanInvalidDialog.observe(this, new Event.Observer<Void>() {
            @Override
            protected void onEvent(final Void v) {
                final DialogBuilder dialog = DialogBuilder.dialog(AddressBookActivity.this,
                        R.string.address_book_options_scan_title, R.string.address_book_options_scan_invalid);
                dialog.singleDismissButton(null);
                dialog.show();
            }
        });

        if (twoPanes) {
            final RecyclerView recyclerView = (RecyclerView) pager.getChildAt(0);
            recyclerView.setClipToPadding(false);

            recyclerView.getViewTreeObserver().addOnGlobalLayoutListener(() -> {
                final int width = recyclerView.getWidth();
                recyclerView.setPadding(0, recyclerView.getPaddingTop(), width / 2, recyclerView.getPaddingBottom());
                pager.setCurrentItem(0);
            });
            pager.setUserInputEnabled(false);
            pagerTabs.setMode(ViewPagerTabs.Mode.STATIC);
        } else {
            pager.setPageTransformer(new ZoomOutPageTransformer());
            pager.registerOnPageChangeCallback(pagerTabs.getPageChangeCallback());
            pagerTabs.setMode(ViewPagerTabs.Mode.DYNAMIC);
        }

        pager.setOffscreenPageLimit(1);
        pager.setAdapter(new AddressBookActivity.PagerAdapter());

        addMenuProvider(new MenuProvider() {
            @Override
            public void onCreateMenu(final Menu menu, final MenuInflater inflater) {
                inflater.inflate(R.menu.address_book_activity_options, menu);
            }

            @Override
            public void onPrepareMenu(final Menu menu) {
                final PackageManager pm = getPackageManager();
                menu.findItem(R.id.sending_addresses_options_scan).setVisible(pm.hasSystemFeature(PackageManager.FEATURE_CAMERA)
                        || pm.hasSystemFeature(PackageManager.FEATURE_CAMERA_FRONT));
            }

            @Override
            public boolean onMenuItemSelected(final MenuItem item) {
                int itemId = item.getItemId();
                if (itemId == R.id.sending_addresses_options_scan) {
                    scanLauncher.launch(null);
                    return true;
                }
                return false;
            }
        });
    }

    private class PagerAdapter extends FragmentStateAdapter {
        public PagerAdapter() {
            super(AddressBookActivity.this);
        }

        @Override
        public int getItemCount() {
            return 2;
        }

        @NonNull
        @Override
        public Fragment createFragment(final int position) {
            if (position == POSITION_WALLET_ADDRESSES)
                return new WalletAddressesFragment();
            else if (position == POSITION_SENDING_ADDRESSES)
                return new SendingAddressesFragment();
            else
                throw new IllegalArgumentException();
        }
    }
}
