/*
 * Copyright the original author or authors.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

package wallet.offline;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.PowerManager;
import android.os.PowerManager.WakeLock;
import androidx.annotation.WorkerThread;
import androidx.core.app.NotificationCompat;
import androidx.lifecycle.LifecycleService;
import org.bitcoinj.core.Transaction;
import org.bitcoinj.core.VerificationException;
import org.bitcoinj.wallet.Wallet;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import wallet.Constants;
import wallet.R;
import wallet.WalletApplication;
import wallet.data.BlockchainServiceLiveData;
import wallet.data.WalletLiveData;
import wallet.util.CrashReporter;
import wallet.util.Toast;

import java.io.IOException;
import java.time.Duration;
import java.time.Instant;

import static com.google.common.base.Preconditions.checkNotNull;

public final class AcceptBluetoothService extends LifecycleService {
    private WalletApplication application;
    private WalletLiveData wallet;
    private WakeLock wakeLock;
    private AcceptBluetoothThread classicThread;
    private AcceptBluetoothThread paymentProtocolThread;

    private Instant serviceCreatedAt;

    private final Handler handler = new Handler();

    private static final Duration TIMEOUT = Duration.ofMinutes(5);

    private static final Logger log = LoggerFactory.getLogger(AcceptBluetoothService.class);

    @Override
    public IBinder onBind(final Intent intent) {
        super.onBind(intent);
        return null;
    }

    @Override
    public int onStartCommand(final Intent intent, final int flags, final int startId) {
        super.onStartCommand(intent, flags, startId);

        handler.removeCallbacks(timeoutRunnable);
        handler.postDelayed(timeoutRunnable, TIMEOUT.toMillis());

        return START_NOT_STICKY;
    }

    @Override
    public void onCreate() {
        serviceCreatedAt = Instant.now();
        log.debug(".onCreate()");

        super.onCreate();
        this.application = (WalletApplication) getApplication();
        final BluetoothManager bluetoothManager = getSystemService(BluetoothManager.class);
        final BluetoothAdapter bluetoothAdapter = checkNotNull(bluetoothManager.getAdapter());
        final PowerManager pm = getSystemService(PowerManager.class);

        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, getClass().getName());
        wakeLock.acquire();

        final NotificationCompat.Builder notification = new NotificationCompat.Builder(this,
                Constants.NOTIFICATION_CHANNEL_ID_ONGOING);
        notification.setColor(getColor(R.color.fg_network_significant));
        notification.setSmallIcon(R.drawable.stat_notify_bluetooth_24dp);
        notification.setContentTitle(getString(R.string.notification_bluetooth_service_listening));
        notification.setWhen(Instant.now().toEpochMilli());
        notification.setOngoing(true);
        notification.setPriority(NotificationCompat.PRIORITY_LOW);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q)
            startForeground(Constants.NOTIFICATION_ID_BLUETOOTH, notification.build(),
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE);
        else
            startForeground(Constants.NOTIFICATION_ID_BLUETOOTH, notification.build());

        registerReceiver(bluetoothStateChangeReceiver, new IntentFilter(BluetoothAdapter.ACTION_STATE_CHANGED));

        try {
            classicThread = new AcceptBluetoothThread.ClassicBluetoothThread(bluetoothAdapter) {
                @Override
                public boolean handleTx(final Transaction tx) {
                    return AcceptBluetoothService.this.handleTx(tx);
                }
            };
            paymentProtocolThread = new AcceptBluetoothThread.PaymentProtocolThread(bluetoothAdapter) {
                @Override
                public boolean handleTx(final Transaction tx) {
                    return AcceptBluetoothService.this.handleTx(tx);
                }
            };
        } catch (final IOException x) {
            new Toast(this).longToast(R.string.error_bluetooth, x.getMessage());
            log.warn("problem with listening, stopping service", x);
            CrashReporter.saveBackgroundTrace(x, application.packageInfo());
            stopSelf();
        }

        wallet = new WalletLiveData(application);
        wallet.observe(this, wallet -> {
            classicThread.start();
            paymentProtocolThread.start();
        });
    }

    @WorkerThread
    private boolean handleTx(final Transaction tx) {
        log.info("tx {} arrived via blueooth", tx.getTxId());

        final Wallet wallet = this.wallet.getValue();
        try {
            if (wallet.isTransactionRelevant(tx)) {
                wallet.receivePending(tx, null);
                handler.post(() -> new BlockchainServiceLiveData(this).observe(this,
                        blockchainService -> blockchainService.broadcastTransaction(tx)));
            } else {
                log.info("tx {} irrelevant", tx.getTxId());
            }

            return true;
        } catch (final VerificationException x) {
            log.info("cannot verify tx " + tx.getTxId() + " received via bluetooth", x);
        }

        return false;
    }

    @Override
    public void onDestroy() {
        if (paymentProtocolThread != null)
            paymentProtocolThread.stopAccepting();
        if (classicThread != null)
            classicThread.stopAccepting();

        unregisterReceiver(bluetoothStateChangeReceiver);

        wakeLock.release();

        handler.removeCallbacksAndMessages(null);

        super.onDestroy();

        log.info("service was up for " + Duration.between(serviceCreatedAt, Instant.now()).toMinutes() + " minutes");
    }

    private final BroadcastReceiver bluetoothStateChangeReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(final Context context, final Intent intent) {
            final int state = intent.getIntExtra(BluetoothAdapter.EXTRA_STATE, 0);

            if (state == BluetoothAdapter.STATE_TURNING_OFF || state == BluetoothAdapter.STATE_OFF) {
                log.info("bluetooth was turned off, stopping service");

                stopSelf();
            }
        }
    };

    private final Runnable timeoutRunnable = () -> {
        log.info("timeout expired, stopping service");

        stopSelf();
    };
}
